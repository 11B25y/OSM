//
//  OSMTests.swift
//  OSMTests
//
//  Created by D OSMOSIS on 22/09/2024.
//

import Testing
@testable import OSM

struct OSMTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
