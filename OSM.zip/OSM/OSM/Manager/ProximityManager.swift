import Foundation
import MultipeerConnectivity
import CoreBluetooth
import CoreData
import Combine
import CoreLocation

class ProximityManager: NSObject, ObservableObject, CBCentralManagerDelegate, MCSessionDelegate, MCNearbyServiceAdvertiserDelegate, MCNearbyServiceBrowserDelegate {

    
    // MARK: - Singleton Instance
    static let shared = ProximityManager(context: PersistenceController.shared.container.viewContext)

    // MARK: - Properties
    private let serviceType = "proximity1"
    private let storedPeersKey = "storedConnectedPeers"
    
    var peerID: MCPeerID!
    private var session: MCSession!
    private var advertiser: MCNearbyServiceAdvertiser!
    private var browser: MCNearbyServiceBrowser!
    private var centralManager: CBCentralManager?

    // MARK: - Discovery Configuration
    private var maxDiscoveryDistance: Double = 100.0  // Default 100 meters
    private var showSubscribedOnly = false
    private var lastKnownLocations: [MCPeerID: CLLocation] = [:]
    
    @Published var isAdvertising = false
    @Published var isBrowsing = false
    @Published var bluetoothEnabled = false
    @Published var receivedMessages: [String] = []
    @Published var connectedPeers: [SelectedPeer] = []
    @Published var reconnecting = false
    @Published var isScanning = false
    @Published var currentUserProfile: UserProfile?
    @Published var receivedInvitationFromPeer: IdentifiablePeer?
    @Published var error: Error?
    @Published var useMockProfiles = false
    
    private var currentInvitationHandler: ((Bool, MCSession?) -> Void)?
    var managedObjectContext: NSManagedObjectContext
    
    // MARK: - Initializer
    private init(context: NSManagedObjectContext) {
        self.managedObjectContext = context
        super.init()
        
        setupPeerID()  // Ensure peerID is set before using it
        populateProfileIfNeeded()
        loadLoggedInProfile()  // This should not be removed!
        
        self.session = MCSession(peer: self.peerID, securityIdentity: nil, encryptionPreference: .required)
        self.advertiser = MCNearbyServiceAdvertiser(peer: self.peerID, discoveryInfo: nil, serviceType: serviceType)
        self.browser = MCNearbyServiceBrowser(peer: self.peerID, serviceType: serviceType)
        
        self.session.delegate = self
        self.advertiser.delegate = self
        self.browser.delegate = self
        
        self.centralManager = CBCentralManager(delegate: self, queue: nil)
        checkBluetoothStatus()
        loadAndReconnectPeers()
    }
    
    // MARK: - Bluetooth State Management
    func centralManagerDidUpdateState(_ central: CBCentralManager) {
        DispatchQueue.main.async {
            self.bluetoothEnabled = central.state == .poweredOn
            if self.bluetoothEnabled {
                self.startDiscovery()
            } else {
                self.stopDiscovery()
            }
        }
    }
    
    func checkBluetoothStatus() {
        if let central = centralManager {
            centralManagerDidUpdateState(central)
        } else {
            print("⚠️ Central manager is not initialized yet.")
        }
    }
    func populateProfileIfNeeded() {
        guard let validPeerID = peerID else {
            print("Error: PeerID is nil, cannot fetch user profile.")
            return
        }

        if currentUserProfile == nil {
            currentUserProfile = fetchUserProfile(for: validPeerID)
            
            if currentUserProfile == nil {
                print("No user profile found; populate as needed.")
            }
        }
        print("ProximityManager Profile: \(currentUserProfile?.wrappedUsername ?? "None")")
    }

    // MARK: - PeerID Setup
    private func setupPeerID() {
        if let username = currentUserProfile?.wrappedUsername, !username.isEmpty {
            self.peerID = MCPeerID(displayName: username)
        } else {
            self.peerID = MCPeerID(displayName: UIDevice.current.name)
        }
        print("PeerID set to: \(peerID.displayName)")
    }
    
    // MARK: - PeerID Retrieval
    func getPeerID() -> MCPeerID {
        return self.peerID
    }

    // MARK: - Discovery Methods
    func startDiscovery() {
        if !useMockProfiles {
            if !isAdvertising {
                advertiser.startAdvertisingPeer()
                isAdvertising = true
                print("Started advertising peer on \(peerID.displayName)")
            }
            if !isBrowsing {
                browser.startBrowsingForPeers()
                isBrowsing = true
                print("Started browsing for peers on \(peerID.displayName)")
            }
        }
        isScanning = true
    }

    func stopDiscovery() {
        if isAdvertising {
            advertiser.stopAdvertisingPeer()
            isAdvertising = false
        }
        if isBrowsing {
            browser.stopBrowsingForPeers()
            isBrowsing = false
        }
        isScanning = false
    }

    func updateDiscoveryDistance(_ distance: Double) {
        maxDiscoveryDistance = max(0, distance)  // Ensure non-negative
        print("Updated discovery distance to: \(maxDiscoveryDistance) meters")
        
        // Filter existing peers based on new distance
        filterPeersByDistance()
    }

    func updateSubscriptionFilter(_ isSubscribed: Bool) {
        showSubscribedOnly = isSubscribed
        print("Subscription filter updated to show only subscribed users: \(showSubscribedOnly)")
        
        // Filter existing peers based on new subscription setting
        filterPeersBySubscription()
    }

    // MARK: - Location-based Discovery
    private func filterPeersByDistance() {
        DispatchQueue.main.async {
            guard let currentLocation = LocationManager.shared.currentLocation else {
                print("Current location unavailable")
                return
            }

            self.connectedPeers.forEach { peer in
                if let peerLocation = self.lastKnownLocations[peer.peerID] {
                    let distance = currentLocation.distance(from: peerLocation)
                    
                    if distance > self.maxDiscoveryDistance {
                        // Disconnect peers outside range
                        print("Peer \(peer.peerID.displayName) outside range (\(Int(distance))m), disconnecting")
                        self.session.disconnect()
                        self.connectedPeers.removeAll { $0.peerID == peer.peerID }
                    }
                }
            }
        }
    }
    private func filterPeersBySubscription() {
        guard showSubscribedOnly else { return }
        
        DispatchQueue.main.async {
            self.connectedPeers.removeAll { peer in
                guard let profile = peer.profile else { return true }
                let isSubscribed = profile.isPremiumUser
                
                if !isSubscribed {
                    print("Removing unsubscribed peer: \(peer.peerID.displayName)")
                    self.session.disconnect()
                }
                
                return !isSubscribed
            }
        }
    }


    // MARK: - Session Management
    private func restartSession() {
        if connectedPeers.isEmpty {
            print("No connected peers to restart the session.")
            return
        }
        
        reconnecting = true
        print("Restarting session...")
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
            self.loadAndReconnectPeers()
        }
    }

    // MARK: - Peer Management
     func saveConnectedPeers() {
         let peerNames = connectedPeers.map { $0.peerID.displayName }
         UserDefaults.standard.set(peerNames, forKey: storedPeersKey)
         print("Saved known peers: \(peerNames)")
     }

    // Change from private to internal or public
    func loadAndReconnectPeers() {
        guard let storedPeerNames = UserDefaults.standard.array(forKey: storedPeersKey) as? [String] else { return }
        print("Loading known peers: \(storedPeerNames)")
        
        for peerName in storedPeerNames {
            reconnectToPeer(MCPeerID(displayName: peerName))
        }
    }
    // Change from private to internal or public
    func reconnectToPeer(_ peerID: MCPeerID) {
        print("Attempting to reconnect to \(peerID.displayName)...")
        browser.invitePeer(peerID, to: session, withContext: nil, timeout: 10)
    }

     // MARK: - Message Handling
     func sendMessage(_ message: String) {
         guard !message.isEmpty, let data = message.data(using: .utf8) else { return }
         send(data: data, to: connectedPeers.map { $0.peerID })
     }

     func send(data: Data, to peers: [MCPeerID]) {
         guard !peers.isEmpty else { return }
         do {
             try session.send(data, toPeers: peers, with: .reliable)
         } catch {
             self.error = error
             print("Error sending data: \(error.localizedDescription)")
         }
     }

    // MARK: - Profile Management
    func createProfile(username: String, email: String, avatarURL: String, bio: String) {
        if let existingProfile = fetchUserProfile(for: peerID) {
            existingProfile.username = username
            existingProfile.email = email
            existingProfile.avatarURL = avatarURL
            existingProfile.bio = bio
            existingProfile.isLoggedIn = true
            existingProfile.peerIDObject = peerID
            print("Updated existing profile: \(existingProfile.username ?? "Unknown")")
        } else {
            let profile = UserProfile(context: managedObjectContext)
            profile.username = username
            profile.email = email
            profile.avatarURL = avatarURL
            profile.bio = bio
            profile.isLoggedIn = true
            profile.peerIDObject = peerID
            print("Created new profile: \(username)")
        }
        
        saveContext()
        print("ProximityManager Profile: \(currentUserProfile?.wrappedUsername ?? "None")")
    }

    // MARK: - Social Media Request Management
    func requestSocialMedia(from requesterID: MCPeerID, to targetID: MCPeerID) {
        guard let targetProfile = fetchUserProfile(for: targetID) else { return }
        var requests = targetProfile.socialMediaRequests as? Set<String> ?? []
        requests.insert(requesterID.displayName)
        targetProfile.socialMediaRequests = requests as NSSet
        saveProfileChanges(targetProfile)
        print("\(requesterID.displayName) requested social media from \(targetID.displayName)")
    }

    func approveSocialMediaRequest(for requesterID: MCPeerID, by targetID: MCPeerID) {
        guard let targetProfile = fetchUserProfile(for: targetID),
              let requesterProfile = fetchUserProfile(for: requesterID) else { return }

        var requests = targetProfile.socialMediaRequests as? Set<String> ?? []
        requests.remove(requesterID.displayName)
        targetProfile.socialMediaRequests = requests as NSSet
        requesterProfile.socialMediaLinks = targetProfile.socialMediaLinks

        saveProfileChanges(targetProfile)
        saveProfileChanges(requesterProfile)
        print("\(targetID.displayName) approved social media request from \(requesterID.displayName)")
    }

    func rejectSocialMediaRequest(for requesterID: MCPeerID, by targetID: MCPeerID) {
        guard let targetProfile = fetchUserProfile(for: targetID) else { return }
        
        if var requests = targetProfile.socialMediaRequests as? Set<String> {
            requests.remove(requesterID.displayName)
            targetProfile.socialMediaRequests = requests as NSSet
            saveProfileChanges(targetProfile)
        }
        
        print("\(targetID.displayName) rejected social media request from \(requesterID.displayName)")
    }

    // MARK: - Profile Caching & Offline Management
    func cachePeerProfile(peerID: MCPeerID, profile: UserProfile, isMatched: Bool = false) {
        let cachedProfile = fetchOrCreateProfile(for: peerID)

        cachedProfile.username = profile.username ?? "Unknown"
        cachedProfile.bio = profile.bio ?? "No bio available"
        cachedProfile.avatarURL = profile.avatarURL
        cachedProfile.email = profile.email ?? "No email"
        cachedProfile.isLoggedIn = isMatched
        
        if isMatched {
            cachedProfile.matchedTimestamp = Date()
        }

        saveProfileChanges(cachedProfile)

        let profileType = isMatched ? "Matched" : "General"
        print("Cached \(profileType) profile for peer: \(peerID.displayName)")
    }

    func fetchOfflineProfiles(includeMatched: Bool = false, includeLocation: Bool = false) -> [UserProfile] {
        let request: NSFetchRequest<UserProfile> = UserProfile.fetchRequest()
        var predicates: [NSPredicate] = [NSPredicate(format: "isLoggedIn == false")]

        if includeMatched {
            predicates.append(NSPredicate(format: "matchedTimestamp != nil"))
        }
        
        request.predicate = NSCompoundPredicate(andPredicateWithSubpredicates: predicates)

        do {
            let profiles = try managedObjectContext.fetch(request)
            return includeLocation ? profiles.filter { $0.latitude != 0.0 && $0.longitude != 0.0 } : profiles
        } catch {
            print("Failed to fetch offline profiles: \(error.localizedDescription)")
            return []
        }
    }

    func combinedProfiles(includeMatched: Bool = false, includeLocation: Bool = false) -> [UserProfile] {
        let activePeers = connectedPeers.compactMap { $0.profile }
        let offlineProfiles = fetchOfflineProfiles(includeMatched: includeMatched, includeLocation: includeLocation)
        return activePeers + offlineProfiles
    }

    private func fetchUserProfile(for peerID: MCPeerID) -> UserProfile? {
        let request: NSFetchRequest<UserProfile> = UserProfile.fetchRequest()
        request.predicate = NSPredicate(format: "peerID == %@", peerID.displayName)
        return try? managedObjectContext.fetch(request).first
    }

    private func fetchOrCreateProfile(for peerID: MCPeerID) -> UserProfile {
        if let existingProfile = fetchUserProfile(for: peerID) {
            return existingProfile
        }
        let profile = UserProfile(context: managedObjectContext)
        profile.peerIDObject = peerID
        profile.username = "Unknown User"
        saveProfileChanges(profile)
        return profile
    }
    // MARK: - Profile Loading and Management
    func loadCachedProfile() {
        print("Loading last cached user profile...")
        if let lastLoggedProfile = UserProfile.fetchLoggedInUser(context: managedObjectContext) {
            self.currentUserProfile = lastLoggedProfile
            print("Loaded cached profile: \(lastLoggedProfile.wrappedUsername)")
        } else {
            print("No cached profile found.")
        }
    }
    func loadLoggedInProfile() {
        print("Loading logged-in user profile...")
        if let loggedInProfile = UserProfile.fetchLoggedInUser(context: managedObjectContext) {
            self.currentUserProfile = loggedInProfile
            setupPeerID()
            print("Loaded profile: \(loggedInProfile.wrappedUsername)")
        } else {
            print("No logged-in profile found. Checking cache...")
            loadCachedProfile()
        }
        loadAndReconnectPeers()
    }

    func syncPeerLocation(peerID: MCPeerID, location: CLLocation) {
        if let profile = fetchUserProfile(for: peerID) {
            profile.latitude = location.coordinate.latitude
            profile.longitude = location.coordinate.longitude
            saveProfileChanges(profile)
            print("Synced location for peer: \(peerID.displayName)")
        } else {
            print("No profile found for peer \(peerID.displayName). Cannot sync location.")
        }
    }
    
    func saveProfileChanges(_ profile: UserProfile) {
        do {
            try managedObjectContext.save()
            print("Profile saved successfully.")
        } catch let error as NSError {
            print("Failed to save profile: \(error), \(error.userInfo)")
        }
    }
    
    func saveContext() {
        do {
            try managedObjectContext.save()
            print("Context saved successfully.")
        } catch let error as NSError {
            print("Failed to save context: \(error.localizedDescription)")
            self.error = error
        }
    }
    
    func markCurrentUserAsOffline() {
        guard let userProfile = currentUserProfile else {
            print("No logged-in user profile to mark as offline.")
            return
        }
        userProfile.isLoggedIn = false
        saveProfileChanges(userProfile)
        saveConnectedPeers()
        print("User marked as offline: \(userProfile.wrappedUsername)")
    }

    // MARK: - MCSessionDelegate
    func session(_ session: MCSession, peer peerID: MCPeerID, didChange state: MCSessionState) {
        DispatchQueue.main.async {
            switch state {
            case .connected:
                print("Peer connected: \(peerID.displayName)")
                if !self.connectedPeers.contains(where: { $0.peerID == peerID }) {
                    let profile = self.fetchOrCreateProfile(for: peerID)
                    self.connectedPeers.append(SelectedPeer(id: UUID(), peerID: peerID, profile: profile))
                }
                self.reconnecting = false
                
            case .notConnected:
                print("Peer disconnected: \(peerID.displayName)")
                self.connectedPeers.removeAll { $0.peerID == peerID }
                if self.connectedPeers.isEmpty {
                    self.restartSession()
                }
                
            case .connecting:
                print("Peer connecting: \(peerID.displayName)")
                
            @unknown default:
                print("Unknown state for peer: \(peerID.displayName)")
            }
        }
    }
    
    func session(_ session: MCSession, didReceive data: Data, fromPeer peerID: MCPeerID) {
        if let message = String(data: data, encoding: .utf8) {
            DispatchQueue.main.async {
                self.receivedMessages.append("\(peerID.displayName): \(message)")
            }
        }
    }
    
    func session(_ session: MCSession, didReceive stream: InputStream, withName streamName: String, fromPeer peerID: MCPeerID) {
        print("Received stream \(streamName) from peer: \(peerID.displayName)")
    }
    
    func session(_ session: MCSession, didStartReceivingResourceWithName resourceName: String, fromPeer peerID: MCPeerID, with progress: Progress) {
        print("Started receiving resource \(resourceName) from peer: \(peerID.displayName)")
    }
    
    func session(_ session: MCSession, didFinishReceivingResourceWithName resourceName: String, fromPeer peerID: MCPeerID, at url: URL?, withError error: Error?) {
        if let error = error {
            print("Failed to receive resource \(resourceName) from peer \(peerID.displayName): \(error.localizedDescription)")
        } else if let url = url {
            print("Successfully received resource \(resourceName) from peer \(peerID.displayName) at URL: \(url)")
        }
    }
    
    // MARK: - MCNearbyServiceAdvertiserDelegate
    func advertiser(_ advertiser: MCNearbyServiceAdvertiser, didReceiveInvitationFromPeer peerID: MCPeerID, withContext context: Data?, invitationHandler: @escaping (Bool, MCSession?) -> Void) {
        DispatchQueue.main.async {
            self.receivedInvitationFromPeer = IdentifiablePeer(peerID: peerID)
            self.currentInvitationHandler = invitationHandler
            print("Received invitation from peer: \(peerID.displayName)")
        }
    }
    
    func advertiser(_ advertiser: MCNearbyServiceAdvertiser, didNotStartAdvertisingPeer error: Error) {
        DispatchQueue.main.async {
            self.error = error
            print("Failed to start advertising: \(error.localizedDescription)")
        }
    }
    
    func respondToInvitation(accepted: Bool) {
        currentInvitationHandler?(accepted, accepted ? session : nil)
        receivedInvitationFromPeer = nil
    }
    
    // MARK: - MCNearbyServiceBrowserDelegate
    func browser(_ browser: MCNearbyServiceBrowser, foundPeer peerID: MCPeerID, withDiscoveryInfo info: [String: String]?) {
        DispatchQueue.main.async {
            if !self.connectedPeers.contains(where: { $0.peerID == peerID }) {
                let profile = self.fetchOrCreateProfile(for: peerID)
                self.connectedPeers.append(SelectedPeer(id: UUID(), peerID: peerID, profile: profile))
            }
        }
    }
    
    func browser(_ browser: MCNearbyServiceBrowser, lostPeer peerID: MCPeerID) {
        DispatchQueue.main.async {
            self.connectedPeers.removeAll { $0.peerID == peerID }
        }
    }
    
    func browser(_ browser: MCNearbyServiceBrowser, didNotStartBrowsingForPeers error: Error) {
        DispatchQueue.main.async {
            self.error = error
            print("Error starting browsing for peers: \(error.localizedDescription)")
        }
    }
    
    // MARK: - Cleanup
    deinit {
        session.disconnect()
        stopDiscovery()
    }
}
