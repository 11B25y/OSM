//
//  UserProfile+CoreDataClass.swift
//  OSM
//
//  Created by D OSMOSIS on 26/01/2025.
//
//

import Foundation
import CoreData

@objc(UserProfile)
public class UserProfile: NSManagedObject {

}
